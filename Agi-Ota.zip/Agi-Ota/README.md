# AGI & OTA
Clareza nas finanças, leveza na vida

## Integrantes do Projeto:
- Alan Araujo - 2401855
- Ana Cláudia Monteiro - 2400505
- Fernanda Figueiredo - 2401803
- João Pedro - 2400834



## Quem nos somos
Somos um banco digital com foco em empréstimos e  em gestão financeira.

Nosso objetivo é ajudar nossos clientes a evitarem gastos desnecessários 

Priorizamos sempre a clareza com nossos clientes


