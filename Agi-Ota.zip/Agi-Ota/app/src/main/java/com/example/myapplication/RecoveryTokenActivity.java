package com.example.myapplication;

import android.app.Activity;

public class RecoveryTokenActivity extends Activity {
}
